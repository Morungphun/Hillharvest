
import React from "react";

export default function HillHarvest() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <h1 style={{ fontSize: '2.5rem', color: '#166534' }}>Hill Harvest</h1>
      <p style={{ fontSize: '1.2rem', color: '#4B5563' }}>
        Fresh Dairy & Vegetables from the Hills of Manipur
      </p>
      <section style={{ marginTop: '2rem' }}>
        <h2>Our Products</h2>
        <ul>
          <li>Cow Milk</li>
          <li>Ghee</li>
          <li>Curd</li>
          <li>Tomato</li>
          <li>Cabbage</li>
          <li>Chilli</li>
        </ul>
      </section>
      <section style={{ marginTop: '2rem' }}>
        <h2>Order Online</h2>
        <form style={{ display: 'flex', flexDirection: 'column', gap: '1rem', maxWidth: '400px' }}>
          <input placeholder="Your Name" required />
          <input placeholder="Product (e.g., Milk, Tomato)" required />
          <input placeholder="Quantity (e.g., 1 litre, 2 kg)" required />
          <input placeholder="Delivery Address" required />
          <input placeholder="Phone Number" required defaultValue="8729910139" />
          <button type="submit" style={{ backgroundColor: '#166534', color: 'white', padding: '0.5rem' }}>
            Place Order
          </button>
        </form>
      </section>
      <footer style={{ marginTop: '2rem', fontSize: '0.9rem', color: '#9CA3AF' }}>
        &copy; 2025 Hill Harvest. All rights reserved.
      </footer>
    </div>
  );
}
