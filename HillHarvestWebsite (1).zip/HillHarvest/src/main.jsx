
import React from 'react'
import ReactDOM from 'react-dom/client'
import HillHarvest from './HillHarvest'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <HillHarvest />
  </React.StrictMode>
)
